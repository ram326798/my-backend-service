package com.example.demo.controllers;

import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Optional;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Login;
import com.example.demo.pojo.Register;
import com.example.demo.repositaries.RegisterRepository;

@RestController

//@CrossOrigin(origins = "http://localhost:3001")

public class ApplicationController {

	private static String secretKey = "academyinsurance";
	private static String salt = "ssshhhhhhhhhhh!!!!";

	@Autowired
	RegisterRepository registerRepository;

	// To check and register the values of user

	@RequestMapping(method = RequestMethod.POST, value = "/register")
	public boolean save(@RequestBody Register register) {
		System.out.println("register page");
		Iterable<Register> alldata = registerRepository.findAll();
		for (Register value : alldata) {
			if ((value.getUserName().equals(register.getUserName()))
					|| (value.getEmailAddress().equals(register.getEmailAddress()))) {
				return false;
			}
		}
		register.setPassword(encrypt(register.getPassword(), secretKey));
		registerRepository.save(register);
		return true;

	}

	// To check the password and username while login

	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public String userLogin(@RequestBody Login data) {
		System.out.println("i'm in");
		String pwd = "";
		String initial = "invalid credentials";
		System.out.println(data.getUserName());
		System.out.println(data.getPassword());
		Optional<Register> alldata = registerRepository.findByUserName(data.getUserName());

		if (alldata.isPresent()) {
			Register datas = alldata.get();
			pwd = decrypt(datas.getPassword(), secretKey);
			if (pwd.equals(datas.getPassword())) {
//						Optional<Register> role1 = registerRepository.findByUserName(data.getUserName());
				System.out.println(datas.getUserName() + "successfull login");

			}
			return "Welcome";
		} else {
			return initial;
		}

	}

	// To get the details of particular username

	@RequestMapping(method = RequestMethod.GET, value = "/{userName}")
	public Optional<Register> show(@PathVariable String userName) {
		System.out.println("in userfor");
		return registerRepository.findByUserName(userName);
	}

	// To edit the details of particular username

	@RequestMapping(method = RequestMethod.PUT, value = "/Edit/{userName}")
	public Register update(@PathVariable String userName, @RequestBody Register register) {
		System.out.println("edit");
		Optional<Register> optcontact = registerRepository.findByUserName(userName);
		Register c = optcontact.get();
		if (register.getContactNumber() != null)
			c.setContactNumber(register.getContactNumber());
		if (register.getEmailAddress() != null)
			c.setEmailAddress(register.getEmailAddress());

		registerRepository.save(c);
		return c;
	}

	// Encrytion of password

	public static String encrypt(String strToEncrypt, String secret) {
		String encyptedPassword;
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);

			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			encyptedPassword = Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
			return encyptedPassword;
		} catch (Exception e) {
			System.out.println("Error while encrypting: " + e.toString());
		}
		return null;
	}

	// Decryption of password

	public static String decrypt(String strToDecrypt, String secret) {

		String decryptedPassword;
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);

			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			decryptedPassword = new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
			return decryptedPassword;
		} catch (Exception e) {
			System.out.println("Error while decrypting: " + e.toString());
		}
		return null;
	}

}
