package com.example.demo.repositaries;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.pojo.Login;

public interface LoginRepository extends MongoRepository<Login, String> {

	Optional<Login> findByUserName(String userName);

}
