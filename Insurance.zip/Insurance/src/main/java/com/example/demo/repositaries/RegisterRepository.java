package com.example.demo.repositaries;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.example.demo.pojo.Register;

public interface RegisterRepository extends MongoRepository<Register, String> {
	@Query("{ 'UserName' : ?0 }")
	Optional<Register> findByUserName(String userName);

//	List<Register> findAll();
	Boolean existsByUserName(String userName);

	Boolean existsByEmailAddress(String emailAddress);

}
