package com.example.demo.respository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.example.demo.models.Register;

public interface RegisterRepository extends MongoRepository<Register, String> {
//	@Query("{ 'Username' : ?0 }")
	Optional<Register> findByUsername(String username);

//	List<Register> findAll();
	Boolean existsByUsername(String username);

	Boolean existsByEmailAddress(String emailAddress);

}
